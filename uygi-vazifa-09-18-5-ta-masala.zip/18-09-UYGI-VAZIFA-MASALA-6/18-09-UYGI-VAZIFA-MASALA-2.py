class Restoran:
    def __init__(self, i, m):
        self.ish_vaqti = i
        self.menyu = m 
    def ovqat_qoshish(self, ovqat, narx):
        self.menyu[ovqat] = narx 
        print(f"{ovqat} - qo'shildi menyuga! Uning narxi {narx}$!")
c1 = Restoran("16:35", {})  
c1.ovqat_qoshish("chuchvara", 9929298626)
