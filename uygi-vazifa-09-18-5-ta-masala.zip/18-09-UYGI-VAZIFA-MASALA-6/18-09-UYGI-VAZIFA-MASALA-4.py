class phone:
    def __init__(self, b,m,n,y):
        self.brand= b
        self.model=m 
        self.narxx=n
        self.yil=y
        print(f"bu telefoni brendi {self.brand},\nkopaniyasini telefon modeli=\n{self.model},\nva arzon narx ! narxi={self.narxx},\nyashagan yili{self.yil}")
    def  update_price (self,narx):
        self.narxx=narx 
        print(f"Yengi telefonga narx berildi!,Uning narxi {self.narxx}$!")
c1 = phone("Samsung"," Galaxy S24 Ultra",99999999999,0)  
c1. update_price (9929298626)