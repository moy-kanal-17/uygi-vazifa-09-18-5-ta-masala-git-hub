class Avto:
    def __init__(self, no, r, na, p, t):
        self.nomi = no
        self.rangi = r
        self.narxi = na
        self.probegi = p
        self.tezligi = t
        print(f"nomi-{self.nomi}\nrangi{self.rangi},\n narxi {self.narxi}")

    def update_probeg(self, yangi_probeg):
        self.probegi = yangi_probeg
        print(f"yangi probeg berildi! u mana={yangi_probeg}")

    def update_narx(self, yangi_narx):
        self.narxi = yangi_narx
c1=Avto("BMW", "Qora", "999999$","-1","450 k/h" )
c1.update_probeg(0)
print(c1)
