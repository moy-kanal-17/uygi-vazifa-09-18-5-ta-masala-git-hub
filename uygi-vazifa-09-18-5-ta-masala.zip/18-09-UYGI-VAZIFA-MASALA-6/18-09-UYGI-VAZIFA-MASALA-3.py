class User:
    def __init__(self, n, us):
        self.name = n
        self.username = us
        self.followers = []
        self.following = []
    def follow(self, user):
        if user not in self.following:
            self.following.append(user)
            self.followers.append(user)
            print("yengi potpishik qoshildi!")
        else:
            print("bunaqa link yoq!")
    def unfollow(self, user):
        if user in self.following:
            self.following.remove(user)
            print("kechirasiz agar sizga bu odam yoqmagan bolsa(")
        else:
            print("siz bu odamga obuna bolmagansiz!")
    def remove_follower(self, user):
        if user in self.followers:
            self.followers.remove(user)
            print("bu potpishik ochirildi !")
        else:
            print("bu odam hech qachon sizga obuna bolmagan!")
c1=User("Moy-kanal-17", "Etmima)")
c1.follow("KING")
c1.unfollow("KING")
c1.follow("KING")
c1.remove_follower("KING")

