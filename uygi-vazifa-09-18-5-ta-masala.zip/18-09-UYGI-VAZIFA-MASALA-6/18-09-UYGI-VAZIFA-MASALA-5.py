class Employee:
    def __init__(self, i, f, id, l, m, b):
        self.ism = i
        self.familiya = f
        self.ishga_joylashgan_sana = id
        self.lavozim = l
        self.maosh = m
        self.bonus = b
        print(f"Hodim: {self.ism} {self.familiya}, Lavozimi: {self.lavozim}, Maoshi: {self.maosh}, Bonus: {self.bonus}")
    
    def update_bonus(self):
        if self.maosh < 10_000_000:
            self.bonus = self.maosh * 0.25
            self.maosh += self.bonus
            print(f"Bonus qo'shildi! Yangi maosh: {self.maosh}, Bonus: {self.bonus}")
        else:
            print(f"{self.ism} {self.familiya} uchun bonus kerak emas. Maoshi yetarli.")
employee1 = Employee("Abduqodir", "Faxriddinov", "2020-05-12", "Dasturchi", 8_000_000, 0)
employee1.update_bonus()

employee2 = Employee("Olim", "Olimov", "2022-01-05", "Menejer", 12_000_000, 0)
employee2.update_bonus()
