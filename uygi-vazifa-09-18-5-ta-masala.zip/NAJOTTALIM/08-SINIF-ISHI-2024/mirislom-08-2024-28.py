a=(input("ism kiriting!"))
print("salom {}".format(a))
c=15
b='salom'
g="yoshti bola, ismi-esa.."
print(b,c,g,a, end=" ")