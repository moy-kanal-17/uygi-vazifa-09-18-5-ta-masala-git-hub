def kvadrat_ildiz(x):
    r = x
    aniqlik = 0.00001
    while (r - x / r) > aniqlik:
        r = (r + x / r) / 2
    return r
balandlik = float(input("Balandlikni kiriting: "))
kenglik = float(input("Kenglikni kiriting: "))
diagonal = kvadrat_ildiz(balandlik**2 + kenglik**2)
print(f"Diogonal uzunligi: {diagonal:.2f}")
