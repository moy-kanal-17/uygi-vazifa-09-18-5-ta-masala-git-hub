import math
r = float(input("Aylana radiusini kiriting: "))
uzunlik = 2 * math.pi * r
print(f"Aylananing uzunligi: {uzunlik:.2f}")