h = 5
for i in range(1, h * 2):
    if i<=h:
        print(" * " * i)
    else:
        print(" * " * (h * 2 - i))
