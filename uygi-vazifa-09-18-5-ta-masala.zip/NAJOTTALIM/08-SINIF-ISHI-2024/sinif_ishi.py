a=5
if a>10:
    print("salom")
elif a>7:
    print("HELLO world")
elif a>4:
    print("salom dunyo!")
