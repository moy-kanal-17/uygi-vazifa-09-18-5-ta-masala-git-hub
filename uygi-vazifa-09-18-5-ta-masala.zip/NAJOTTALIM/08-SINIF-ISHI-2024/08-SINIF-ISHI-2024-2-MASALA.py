oy=int(input("oy kiriting"))
if oy==1:
    print("yilni 1 oyi=qishni 2 oyi")
elif oy==2:
    print("yilni 2 oyi=qishning 3 oyi")
elif oy==3:
    print("yilni 3 oyi=bohorning 1 oyi")
elif oy==4:
    print("yilni 4 oyi=bohorning 2 oyi")
elif oy==5:
    print("yilni 5 oyi=bohorning 3 oyi")
elif oy==6:
    print("yilni 6 oyi=yozning 1 oyi")
elif oy==7:
    print("yilni 7 oyi=yozning 2 oyi")
elif oy==8:
    print("yilni 8 oyi=yozning 3 oyi")
elif oy==9:
    print("yilni 9 oyi=kuzning 1 oyi")
elif oy==10:
    print("yilni 10 oyi=kuzning 2 oyi")
elif oy==11:
    print("yilni 11 oyi=kuzning 3 oyi")
elif oy==12:
    print("yilni 12 oyi=qishning 1 oyi")
else:
    print("bu sonli oy yoq ! ,aldoqchi! ")