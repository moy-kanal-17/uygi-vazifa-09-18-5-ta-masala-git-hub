listt=[1,2,3,4,5,6,7,8]
def func (z):
    return max(z)
print(func(listt))