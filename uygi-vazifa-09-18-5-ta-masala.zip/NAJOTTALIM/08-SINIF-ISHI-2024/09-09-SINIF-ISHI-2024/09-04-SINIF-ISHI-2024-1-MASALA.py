listt=[]
def f(a,b):
    if a>b:
        for i in range(b,a+1):
            listt.append(i)
    if a<b:
        i=a
        for i in range(b):
            listt.append(i)
    if a==b:
        print('sonlar teng !')
        breakpoint()
a=int(input("Ingrese un numero: "))
b=int(input("Ingrese un numero: "))
f(a,b)
print(listt)

