class animall:
    def __init__(self,n):
        self.name=n
    def eat(self, food,drink):
        print(f"{self.name}I am eating {food} and drink {drink}!")
class dog (animall):
    def __init__(self, n,z,r,y):
        self.name=n
        self.zot=z
        self.rang=r
        self.yosh=y
        super(n)
class cat (animall):
    pass
d1=animall("Dog:")
c1=animall("CAT:")
d1.zot=("Ta")
d1.rang
d1= dog("\033[31mDOG\033[0m-Tom:")
c1= cat ("\033[31mCAT\033[0m-baroq:")
d1.eat("meat", "COLA")
c1.eat("Milk","FISH")
    
        