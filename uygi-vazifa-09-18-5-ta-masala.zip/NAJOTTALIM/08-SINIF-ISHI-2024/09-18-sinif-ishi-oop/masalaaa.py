class MyClass:
    def __init__(self, n, i):
        self.name=n
        self.ish=i
c1=MyClass("usta", "qurish")
c2=MyClass("Militsiya", "qoriqlash")
print(c1)
