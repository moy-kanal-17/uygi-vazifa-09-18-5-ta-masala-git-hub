class Market:
    def __init__(self, name):
        self.name = name 
        self.savat = {}
    def mahsulot_qosh(self, mahsulot_nomi, narx):
        if mahsulot_nomi not in self.savat:
            self.savat[mahsulot_nomi] = narx
            print(f"{mahsulot_nomi} savatga qo'shildi.")
        else:
            print(f"Bu {mahsulot_nomi} savatda bor.")
    def mahsulot_ayir(self, mahsulot_nomi):
        if mahsulot_nomi in self.savat:
            del self.savat[mahsulot_nomi]
            print(f"{mahsulot_nomi} savatdan o'chirildi.")
        else:
            print(f"Bunday {mahsulot_nomi} savatda yo'q.")
    def buyurtma_qilish(self):
        if not self.savat:
            print("Sizning savatingiz bo'sh!")
        else:
            umumiy_summa = 0
            print(f"\n{self.name}ning savati:\n")
            for mahsulot, narx in self.savat.items():
                print(f"{mahsulot}: {narx} so'm")
                umumiy_summa += narx
            print(f"\nUmumiy summa: {umumiy_summa} so'm\n")
xaridor = Market("Abduqodir")
xaridor.mahsulot_qosh("Olma", 5000)
xaridor.mahsulot_qosh("Non", 2000)
xaridor.mahsulot_qosh("Olma", 5000)
xaridor.mahsulot_ayir("Non")
xaridor.mahsulot_ayir("Sut") 
xaridor.buyurtma_qilish()

