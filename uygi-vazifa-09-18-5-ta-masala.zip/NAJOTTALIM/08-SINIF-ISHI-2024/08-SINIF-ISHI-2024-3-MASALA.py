ball=float(input("BALINGIZNI KIRITING: "))
if ball<60:
    print("Afsus, siz imtihondan yiqilgansiz")
if ball>100 or ball<0:
    print("Afsus, siz notog'ri raqam kiritingiz")
if ball>60 and ball<=100:
    print("Tabriklaymiz! Siz imtihondan o’tgansiz!, kengi safar yeqitamiz)")

else:
    print("Tabriklaymiz!,aldaganiz uchun haydalasiz!")