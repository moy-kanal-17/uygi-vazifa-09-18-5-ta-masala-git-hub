list={1,2,3,4,5,6,7,8,17,9}
sd={1,17,2,3,4,5,6,7,8,9}
sd2=list.difference(sd)
if len(sd2)==0:
    print("son yoq faqat bunda bor!")
if len(sd2)==1:
    print(f'{sd2} - faqat bu lista bor son!')
else:
    print(f'{sd2} - faqat bu lista bor sonlar!')
