set1={'Artel','Alif','Yandex', 'Google', 'Meta'}
set2={'Google', 'Apple', 'Amazon', 'Meta'}
set3={'Alibaba', 'Uzum', 'Meta', 'Google', 'Amazon'}
set4={}
set4=set1.intersection(set2)
set4=set4.intersection(set3)
set1.difference_update(set2)
set1.difference_update(set3)
print(f'{set1} = birinchi seta ozida bori')
print(f'{set4} = umumi')

