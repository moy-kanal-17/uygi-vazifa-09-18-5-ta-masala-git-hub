set={1,'zor',2,False,2,3,3,4,4,5,5,6,6,7,7,8,9,9,True,0}
set2={'ava'}
if 7 in set:
    print('yes !')
else:
    print('no !')
set.pop()
# set2=set.copy()
set3=set.issubset(set2)
for i in set:
    print(i)
print(set2)
print("kengisi, HARD !")
print(set3)
print(set)
print('zoor')
set.clear()
set2.clear()
set.add(7)
set2.add(7)
print(set.issubset(set2))    