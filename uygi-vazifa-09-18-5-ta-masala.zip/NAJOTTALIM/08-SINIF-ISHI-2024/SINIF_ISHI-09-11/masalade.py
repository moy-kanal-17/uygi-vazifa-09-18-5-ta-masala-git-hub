# import wikipedia as wk
# wk.set_lang('UZ')
# p = wk.page('Apple')
# print(p.summary)
from googletrans import Translator
tarjimon = Translator()
text = "Hi, my name is Ali"
res = tarjimon.translate(text, src='en', dest='uz')
print(res.text)

