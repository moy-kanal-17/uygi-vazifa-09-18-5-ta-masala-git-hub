import cv2
from cv2 import data

face_detect = cv2.CascadeClassifier(data.haarcascades + "haarcascade_frontalface_default.xml")

cam = cv2.VideoCapture(0)

while True:
    ret, image = cam.read()
    faces = face_detect.detectMultiScale(image, minNeighbors=15, minSize=(30,30))
    # print(faces)
    if ret:
        try:
            for (x,y,u,b) in faces:
                cv2.rectangle(image, (x,y), (x+u, y+b), (52, 237, 74), 2)
            cv2.imshow("Kamera", image)
        except:
            pass

    if cv2.waitKey(1) & 0xFF == 32:
        break
