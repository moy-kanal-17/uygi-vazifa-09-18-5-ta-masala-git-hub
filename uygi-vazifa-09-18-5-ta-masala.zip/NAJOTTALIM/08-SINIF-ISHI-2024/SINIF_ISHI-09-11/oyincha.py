import pygame
import time
import random
import cv2
from cv2 import data

# Pygame va OpenCV ni boshlash
pygame.init()

# Ranglar
white = (255, 255, 255)
yellow = (255, 255, 102)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)
blue = (50, 153, 213)

# O'lchamlar
window_width = 600
window_height = 400
dis = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption('Snake Game with Face Detection')

# FPS
clock = pygame.time.Clock()
snake_block = 10
snake_speed = 15

# Shriftlar
font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)

# OpenCV yuz aniqlash
face_detect = cv2.CascadeClassifier(data.haarcascades + "haarcascade_frontalface_default.xml")
cam = cv2.VideoCapture(0)

# Hisobni ko'rsatish funksiyasi
def our_score(score):
    value = score_font.render("Your Score: " + str(score), True, yellow)
    dis.blit(value, [0, 0])

# Ilon harakatini chizish
def our_snake(snake_block, snake_list):
    for x in snake_list:
        pygame.draw.rect(dis, green, [x[0], x[1], snake_block, snake_block])

# Xabar ko'rsatish
def message(msg, color):
    mesg = font_style.render(msg, True, color)
    dis.blit(mesg, [window_width / 6, window_height / 3])

# Menyu yaratish funksiyasi
def game_menu():
    menu = True
    while menu:
        dis.fill(blue)
        message("Welcome to Snake Game! Press S-Start or Q-Quit", yellow)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    menu = False  # O'yinni boshlash uchun menyudan chiqish
                elif event.key == pygame.K_q:
                    pygame.quit()
                    quit()

# O'yin va kamera bilan yuz aniqlash funksiyasi
def gameLoop():
    game_over = False
    game_close = False

    x1 = window_width / 2
    y1 = window_height / 2
    x1_change = 0
    y1_change = 0
    snake_list = []
    length_of_snake = 1

    foodx = round(random.randrange(0, window_width - snake_block) / 10.0) * 10.0
    foody = round(random.randrange(0, window_height - snake_block) / 10.0) * 10.0

    while not game_over:
        while game_close == True:
            dis.fill(blue)
            message("You Lost! Press C-Play Again or Q-Quit", red)
            our_score(length_of_snake - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        gameLoop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x1_change = -snake_block
                    y1_change = 0
                elif event.key == pygame.K_RIGHT:
                    x1_change = snake_block
                    y1_change = 0
                elif event.key == pygame.K_UP:
                    y1_change = -snake_block
                    x1_change = 0
                elif event.key == pygame.K_DOWN:
                    y1_change = snake_block
                    x1_change = 0

        if x1 >= window_width or x1 < 0 or y1 >= window_height or y1 < 0:
            game_close = True

        x1 += x1_change
        y1 += y1_change
        dis.fill(black)

        pygame.draw.rect(dis, white, [foodx, foody, snake_block, snake_block])

        snake_head = []
        snake_head.append(x1)
        snake_head.append(y1)
        snake_list.append(snake_head)

        if len(snake_list) > length_of_snake:
            del snake_list[0]

        for x in snake_list[:-1]:
            if x == snake_head:
                game_close = True

        our_snake(snake_block, snake_list)
        our_score(length_of_snake - 1)
        pygame.display.update()

        # Oziq-ovqatni yeb qo'yish
        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, window_width - snake_block) / 10.0) * 10.0
            foody = round(random.randrange(0, window_height - snake_block) / 10.0) * 10.0
            length_of_snake += 1

        # Kamera bilan yuz aniqlash
        ret, image = cam.read()
        faces = face_detect.detectMultiScale(image, minNeighbors=5, minSize=(30, 30))

        if ret:
            for (x, y, w, h) in faces:
                cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
            cv2.imshow("Face Detection", image)

        if cv2.waitKey(1) & 0xFF == 32:
            break

        clock.tick(snake_speed)

    cam.release()
    cv2.destroyAllWindows()
    pygame.quit()
    quit()

# O'yin boshlanishi uchun menyuni chaqirish
game_menu()  # Menyuni ko'rsatish
gameLoop()   # O'yinni boshlash
from cv2 import data

# Pygame va OpenCV ni boshlash
pygame.init()

# Ranglar
white = (255, 255, 255)
yellow = (255, 255, 102)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)
blue = (50, 153, 213)

# O'lchamlar
window_width = 1000
window_height = 1000
dis = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption('Snake Game with Face Detection')

# FPS
clock = pygame.time.Clock()
snake_block = 60
snake_speed = 10

# Shriftlar
font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)

# OpenCV yuz aniqlash
face_detect = cv2.CascadeClassifier(data.haarcascades + "haarcascade_frontalface_default.xml")
cam = cv2.VideoCapture(0)

# Hisobni ko'rsatish funksiyasi
def our_score(score):
    value = score_font.render("Your Score: " + str(score), True, yellow)
    dis.blit(value, [0, 0])

# Ilon harakatini chizish
def our_snake(snake_block, snake_list):
    for x in snake_list:
        pygame.draw.rect(dis, green, [x[0], x[1], snake_block, snake_block])

# Xabar ko'rsatish
def message(msg, color):
    mesg = font_style.render(msg, True, color)
    dis.blit(mesg, [window_width / 6, window_height / 3])

# Menyu yaratish funksiyasi
def game_menu():
    menu = True
    while menu:
        dis.fill(blue)
        message("Welcome to Snake Game! Press S-Start or Q-Quit", yellow)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    menu = False  # O'yinni boshlash uchun menyudan chiqish
                elif event.key == pygame.K_q:
                    pygame.quit()
                    quit()

# O'yin va kamera bilan yuz aniqlash funksiyasi
def gameLoop():
    game_over = False
    game_close = False

    x1 = window_width / 2
    y1 = window_height / 2
    x1_change = 0
    y1_change = 0
    snake_list = []
    length_of_snake = 1

    foodx = round(random.randrange(0, window_width - snake_block) / 10.0) * 10.0
    foody = round(random.randrange(0, window_height - snake_block) / 10.0) * 10.0

    while not game_over:
        while game_close == True:
            dis.fill(blue)
            message("You Lost! Press C-Play Again or Q-Quit", red)
            our_score(length_of_snake - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        gameLoop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x1_change = -snake_block
                    y1_change = 0
                elif event.key == pygame.K_RIGHT:
                    x1_change = snake_block
                    y1_change = 0
                elif event.key == pygame.K_UP:
                    y1_change = -snake_block
                    x1_change = 0
                elif event.key == pygame.K_DOWN:
                    y1_change = snake_block
                    x1_change = 0

        if x1 >= window_width or x1 < 0 or y1 >= window_height or y1 < 0:
            game_close = True

        x1 += x1_change
        y1 += y1_change
        dis.fill(black)

        pygame.draw.rect(dis, white, [foodx, foody, snake_block, snake_block])

        snake_head = []
        snake_head.append(x1)
        snake_head.append(y1)
        snake_list.append(snake_head)

        if len(snake_list) > length_of_snake:
            del snake_list[0]

        for x in snake_list[:-1]:
            if x == snake_head:
                game_close = True

        our_snake(snake_block, snake_list)
        our_score(length_of_snake - 1)
        pygame.display.update()

        # Oziq-ovqatni yeb qo'yish
        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, window_width - snake_block) / 10.0) * 10.0
            foody = round(random.randrange(0, window_height - snake_block) / 10.0) * 10.0
            length_of_snake += 1

        # Kamera bilan yuz aniqlash
        ret, image = cam.read()
        faces = face_detect.detectMultiScale(image, minNeighbors=35, minSize=(30, 30))

        if ret:
            for (x, y, w, h) in faces:
                cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 66), 2)
            cv2.imshow("Face Detection", image)

        if cv2.waitKey(1) & 0xFF == 32:
            break

        clock.tick(snake_speed)

    cam.release()
    cv2.destroyAllWindows()
    pygame.quit()
    quit()

# O'yin boshlanishi uchun menyuni chaqirish
game_menu()  # Menyuni ko'rsatish
gameLoop()   # O'yinni boshlash
