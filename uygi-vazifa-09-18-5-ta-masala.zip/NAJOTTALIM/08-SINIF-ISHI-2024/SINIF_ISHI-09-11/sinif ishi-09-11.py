import os
import random as rd
import math as m
import os
import sys
#
# try:
#     a = int(input("a: "))
#     b = int(input("b: "))
#     print(a/b)
# except ZeroDivisionError as e:
#     print("Sonlarni 0ga bo'lib bo'lmaydi!")
# except Exception as e:
#     print("Xato qiymat kiritdingiz!", e)
# else:
#     print("Kod xatoliksiz bajarildi!")
# finally:
#     print("Try except tugadi!")
# print(m.pow(2,4))
# print(m.sqrt(121))
# print(m.log(2,4))
# print(m.floor(2.53))
# print(m.ceil(2.28))
# print(rd.randint(1,100))
# print(rd.uniform(1, 10))
# lst = ['Abror', 'Abdulla', 'Kamron', 'Bonu', 'Fotima', 'Shohruh']
# n = rd.choice(lst)
# print(n)
# n1 = rd.sample(lst, 3)
# print(n1)
# print(sys.platform)
# print(sys.path)
# m = sys.maxsize
# print(m)
print(os.getcwd())
# os.mkdir('.py')
# os.mkdir('.po')
# os.rmdir('.py')
# os.rmdir('.po')
#os.rename('sinif ishi-09-12.py', 'sinif ishi-09-11.py')
os.rename('C:', 'D:')