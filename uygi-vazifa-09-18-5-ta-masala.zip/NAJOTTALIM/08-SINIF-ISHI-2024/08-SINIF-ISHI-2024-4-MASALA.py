ball=float(input("nechI narx mahsulot sotip olganizni KIRITING: "))
if ball>500001 and ball<=1000000:
    print("sizga 25% chegirma berildi!")
    ball=ball%25
    print("narh=",ball)
elif ball<=500000 and ball>=100000:
    print(" sizga 15% chegirma berildi!")
    ball=ball%15
    print("narh=",ball)

elif ball>1000000:
    print(" sizga 40% chegirma berildi!")
    ball=ball%40
    print("narh=",ball)
