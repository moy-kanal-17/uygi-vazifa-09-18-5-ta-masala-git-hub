def ll(lst):
    dictionary = {}
    for item in lst:
        key = item[0]
        value = item[1:]
        dictionary[key] = value
    return dictionary
lst = [
    [1, 'Jean Castro', 'V'],
    [2, 'Lula Powell', 'V'],
    [3, 'Brian Howell', 'VI'],
    [4, 'Lynne Foster', 'VI'],
    [5, 'Zachary Simon', 'VII']
]
out = ll(lst)
print(out)
