with open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/ascii_input.txt", 'r') as f:
    numbers = list(map(int, f.read().split()))
average = sum(numbers) / len(numbers)
ro = round(average)
print(f"O'rtacha qiymat: {ro}")
