with open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/masala", 'r') as f:
    content = f.read()
new = content.title()
with open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/masalauchun", 'w') as f:
    f.write(new)
print("So'zlar katta harf bilan yozildi!")
