import json
with open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/masalade.json", 'r') as f:
    us = json.load(f)
login = input("Login kiriting: ")
parol = input("Parol kiriting: ")
if login not in us:
    print("Bunday foydalanuvchi yo'q")
elif us[login] != parol:
    print("Xato parol kiritdingiz")
else:
    print("OK")