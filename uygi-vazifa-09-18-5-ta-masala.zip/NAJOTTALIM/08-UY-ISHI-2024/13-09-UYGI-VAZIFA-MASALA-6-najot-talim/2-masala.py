soz = input("So'z kiriting: ")
f= open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/masala", 'r')
content = f.read()
if soz in content:
    print(f"Bu so'z faylda mavjud: {soz}")
else:
    print("Bu so'z faylda mavjud emas.")
