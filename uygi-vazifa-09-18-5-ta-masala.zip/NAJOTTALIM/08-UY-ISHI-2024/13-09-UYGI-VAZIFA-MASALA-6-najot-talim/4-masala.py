with open("names.txt", 'r') as f:
    names = f.read().splitlines()
unique_names = list(set(names))
with open("unique_names.txt", 'w') as f:
    f.write("\n".join(unique_names))
print("Takrorlangan ismlar o'chirildi!")
 