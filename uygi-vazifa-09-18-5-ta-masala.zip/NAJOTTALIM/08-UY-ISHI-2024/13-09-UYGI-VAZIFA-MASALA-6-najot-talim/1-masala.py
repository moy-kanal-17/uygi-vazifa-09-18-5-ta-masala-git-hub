with open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/ascii_input.txt", 'r') as f:
    ascii_values = f.read().split()
text = ''.join([chr(int(num)) for num in ascii_values])
with open("C:/Users/abduq/ ishim paytonda!/python/NAJOTTALIM/08-UY-ISHI-2024/13-09-UYGI-VAZIFA-MASALA-6/decoded_output.txt", 'w') as f:
    f.write(text)
print("Matn decoded_output.txt fayliga yozildi!")
