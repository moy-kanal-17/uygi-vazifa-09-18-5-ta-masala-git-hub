c=0
i=0
print('n =?')
n=int(input())
while i<n:
    i=i+1
    print(i,end=' ')
    c=c+i
print("yeg'indi -= ..",c)