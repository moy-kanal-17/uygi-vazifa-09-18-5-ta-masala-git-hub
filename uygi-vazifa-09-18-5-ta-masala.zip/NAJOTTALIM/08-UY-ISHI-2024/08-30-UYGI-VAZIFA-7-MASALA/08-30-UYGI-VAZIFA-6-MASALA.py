son = int(input("son =? "))
raqamlar = []

while son > 0:
    raqamlar.insert(0, son % 10)
    son = son // 10
for raqam in reversed (raqamlar):
    print(raqam, end=" ")
