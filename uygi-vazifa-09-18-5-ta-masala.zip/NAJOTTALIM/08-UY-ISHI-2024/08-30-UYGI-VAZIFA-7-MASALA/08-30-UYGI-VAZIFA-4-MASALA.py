print("son =?")
son = int(input())

for i in range(son, 1, -1):
    if i % 2 == 0:
        print(i,end=" ")
