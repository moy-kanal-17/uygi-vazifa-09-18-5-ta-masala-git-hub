def tub_sonmi(son):
    if son < 2:
        return False
    for i in range(2, son):
        if son % i == 0:
            return False
    return True

print("Ikkixonali tub sonlar:")
for son in range(10, 100):
    if tub_sonmi(son):
        print(son, end=" ")
