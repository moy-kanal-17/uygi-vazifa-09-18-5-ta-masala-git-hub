print("a=?")
a=int(input())
if a>=10:
    c=a%100//10
    d=a%100%10
    g=d
    d=c
    c=g
    print(c,d, end="")
else:
    print(a,"== teng yoki kotamas 10 dan!")